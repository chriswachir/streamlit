# zumi-bi-assessment

This is was an assessment for an interview I did with ZUMI. It was about assessing how best I coult get insight from data, that would otherwise inform decisions. 
I successfully created as streamlit app for visualizing the data
